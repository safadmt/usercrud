module.exports = {
    USER_COLLECTION : 'users'
}